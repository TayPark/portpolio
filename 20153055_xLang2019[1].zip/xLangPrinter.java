package xLangExecutor;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

public class xLangPrinter {
	Element root;
	int idx = 0;
	String vars[] = new String[100];	
	
	public boolean checkVar(String[] var, Node e) {
		for(int i = 0; i < idx + 1 ;i++) {
			if (var[i] != null && var[i].equals(e.getTextContent())) {
				return true;
			}
		}
		return false;
	}
	
	public xLangPrinter(Element e) {	
		root = e;
	}

	public void printNode() {
		printNode(root);
	}
	private void printNode(Node e) {

		String name = e.getNodeName();
		
		// xLang statement and Author
		if (name.equals("xLang19")) { 
			//System.out.println("i'm in <xLang19>...");
			Node child = e.getFirstChild();
			printNode(child);
			while ((child = child.getNextSibling()) != null)
				printNode(child);
		}
		else if (name.equals("Author")) {
			System.out.println("// Author: " + e.getTextContent()+"\n");
			System.out.println("#include<stdio.h>");
		}
		
		// Function has 3 children
		else if (name.equals("Function")) {
			System.out.println();
			printNode(e.getFirstChild());
			printNode(e.getFirstChild().getNextSibling());
			printNode(e.getFirstChild().getNextSibling().getNextSibling());
		}
		else if (name.equals("Name")) { // Function name: main
				System.out.print("int "+e.getTextContent());
		}		
		// Define function's parameter
		else if (name.equals("Parameter")) { // (parameter_01, 02, 03, ...)
			Node child = e.getFirstChild();
			System.out.print("(");
			if (child != null) {
				printNode(child);
				while (child.getNextSibling() != null) {
					System.out.print(", ");
					child = child.getNextSibling();
					printNode(child);
				}
			}
			System.out.println(")");
		} ////		
		else if (name.equals("Variable")) {
			if(checkVar(vars, e) && e.getParentNode().getNodeName() != "Parameter") {
				System.out.print(e.getTextContent());
			}
			 else {
				vars[idx] = e.getTextContent();
				idx++;
				System.out.print("int "+e.getTextContent());
			}

		}
		else if (name.equals("Number")) {
			System.out.print(e.getTextContent());
		}
		else if (name.equals("Statement")) {
			Node child = e.getFirstChild();
			System.out.println("{");
			while (child != null) {
				printNode(child);
				child = child.getNextSibling();
			}
			System.out.println("}");
		}
		else if (name.equals("Assign")) {
			Node child = e.getFirstChild();
			while (child != null) {
				printNode(child);
				System.out.print(" = ");
				printNode(child.getNextSibling());
				System.out.println(";");
				child = child.getNextSibling().getNextSibling();
			}
		}
		
		// Actual objectives
		
		// Input
		else if (name.equals("Input")) {
			if(checkVar(vars, e)) {
				System.out.println(e.getFirstChild().getTextContent()+";");
				System.out.println("scanf(\"%d\", &" + e.getFirstChild().getTextContent() + ");");
			} 
			else {
				vars[idx] = e.getTextContent();
				idx++;				
				System.out.println("int "+e.getFirstChild().getTextContent()+";");
				System.out.println("scanf(\"%d\", &" + e.getFirstChild().getTextContent() + ");");
			}			
		}
		else if (name.equals("While")) {
			System.out.print("\nwhile (");
			printNode(e.getFirstChild()); // Conditional statement
			System.out.println(") {");
			printNode(e.getFirstChild().getNextSibling()); // Loop statement 
			System.out.println("}");
		}
		
		else if (name.equals("If")) {
			System.out.print("\nif (");
			printNode(e.getFirstChild());
			System.out.print(") {\n");
			printNode(e.getFirstChild().getNextSibling());
			System.out.println("}");
			if (e.getFirstChild().getNextSibling().getNextSibling() != null) {
				System.out.print("else {");
				printNode(e.getFirstChild().getNextSibling().getNextSibling());
				System.out.println("}");
			}
		}
		
		else if (name.equals("Then")) {
			printNode(e.getFirstChild());
		}
		else if (name.equals("Else")) {
			Node child = e.getFirstChild();
			printNode(child);
			while(child.getNextSibling() != null) {
				child = child.getNextSibling();
				printNode(child);
			}
		}
	
		// Loop
		else if (name.equals("Loop")) {
			Node child = e.getFirstChild();
			while(child != null) {
				printNode(child);
				child = child.getNextSibling();
			}
		}
		///////////////////////////////
		// Fcall
		else if (name.equals("Fcall")) {
			printNode(e.getFirstChild());
			printNode(e.getFirstChild().getNextSibling());
		}
		// Fname
		else if (name.equals("Fname")) {
			if(e.getTextContent().equals("main"))
				System.out.print("int "+e.getTextContent());
			else	
				System.out.print(e.getTextContent());
		}
		// Argument
		else if (name.equals("Argument")) {
			Node child = e.getFirstChild();
			System.out.print("(");
			if (child != null) {
				printNode(child);
				while (child.getNextSibling() != null) {
					System.out.print(", ");
					child = child.getNextSibling();
					printNode(child);

				}
			}
			System.out.print(")");
		}

		// Output
		else if (name.equals("Output")) {
			System.out.println("\nprintf(\"%d\", " + e.getTextContent()+");");
		}
		
		// Return
		else if (name.equals("Return")) {
			System.out.print("\n\treturn ");
			printNode(e.getFirstChild());
			System.out.println(";");
		}
		
		// Plus
		else if (name.equals("Plus")) {
			printNode(e.getFirstChild());
			System.out.print(" + ");
			printNode(e.getFirstChild().getNextSibling());
		}
		
		// Minus
		else if (name.equals("Minus")) {
			printNode(e.getFirstChild());
			System.out.print(" - ");
			printNode(e.getFirstChild().getNextSibling());
		}
		// Multiply
			else if (name.equals("Multiply")) {
				printNode(e.getFirstChild());
				System.out.print(" * ");
				printNode(e.getFirstChild().getNextSibling());	
				}
		// Divide
				else if (name.equals("Divide")) {
					printNode(e.getFirstChild());
					System.out.print(" / ");
					printNode(e.getFirstChild().getNextSibling());
				}
		// Mod
				else if (name.equals("Mod")) {
					printNode(e.getFirstChild());
					System.out.print(" % ");
					printNode(e.getFirstChild().getNextSibling());
				}
	
		
		// Compare operators
		else if (name.equals("EQ")) {
			printNode(e.getFirstChild());
			System.out.print(" == ");
			printNode(e.getFirstChild().getNextSibling());
		}
		else if (name.equals("NE")) {
			printNode(e.getFirstChild());
			System.out.print(" != ");
			printNode(e.getFirstChild().getNextSibling());
		}
		else if (name.equals("GE")) {
			printNode(e.getFirstChild());
			System.out.print(" >= ");
			printNode(e.getFirstChild().getNextSibling());
		}
		else if (name.equals("GT")) {
			printNode(e.getFirstChild());
			System.out.print(" > ");
			printNode(e.getFirstChild().getNextSibling());
		}
		else if (name.equals("LE")) {
			printNode(e.getFirstChild());
			System.out.print(" <= ");
			printNode(e.getFirstChild().getNextSibling());
		}
		else if (name.equals("LT")) {
			printNode(e.getFirstChild());
			System.out.print(" < ");
			printNode(e.getFirstChild().getNextSibling());
		}
		
	}


	
	// For show all
	public void printAll() {
		printAll(root, 0);
	}
	private void printAll(Node node, int indent) {
		if (node == null) return;
		NodeList nodes = node.getChildNodes();
		for (int c = 0; c < nodes.getLength(); c++) {
			for (int i=0; i<indent; i++)
				System.out.print(" ");
			System.out.print(nodes.item(c).getNodeName());
			if (nodes.item(c) instanceof Text) {
				System.out.print(" \"" + nodes.item(c).getTextContent() + "\"");
			}
			System.out.println();
			printAll(nodes.item(c), indent+2);
		}
	}

}